package com.antiquechessmaster.domain.engine

interface ChessEngine {
    suspend fun initialize(): Boolean
    suspend fun analyzePosition(fen: String, depth: Int = 12): EngineAnalysis
    suspend fun getBestMove(fen: String, depth: Int = 12): String?
    suspend fun shutdown()
}

data class EngineAnalysis(
    val bestMove: String?,
    val evaluation: Double, // In pawns, positive = white advantage
    val depth: Int,
    val pv: List<String> = emptyList()
)
// app/src/main/java/com/antiquechessmaster/domain/engine/StockfishEngine.kt
package com.antiquechessmaster.domain.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import java.io.*
import java.util.concurrent.atomic.AtomicBoolean

class StockfishEngine(private val context: Context) : ChessEngine {
    
    private var process: Process? = null
    private var reader: BufferedReader? = null
    private var writer: BufferedWriter? = null
    private val isInitialized = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    companion object {
        private const val TAG = "StockfishEngine"
        private const val DEFAULT_DEPTH = 12
    }
    
    override suspend fun initialize(): Boolean = withContext(Dispatchers.IO) {
        try {
            // Copy stockfish binary from assets to internal storage
            val stockfishFile = File(context.filesDir, "stockfish")
            
            if (!stockfishFile.exists()) {
                context.assets.open("stockfish").use { input ->
                    FileOutputStream(stockfishFile).use { output ->
                        input.copyTo(output)
                    }
                }
                stockfishFile.setExecutable(true)
            }
            
            process = ProcessBuilder(stockfishFile.absolutePath).start()
            reader = BufferedReader(InputStreamReader(process!!.inputStream))
            writer = BufferedWriter(OutputStreamWriter(process!!.outputStream))
            
            sendCommand("uci")
            waitForResponse("uciok")
            
            sendCommand("setoption name Hash value 64")
            sendCommand("setoption name Threads value 2")
            sendCommand("isready")
            waitForResponse("readyok")
            
            isInitialized.set(true)
            Log.d(TAG, "Stockfish initialized successfully")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Stockfish", e)
            false
        }
    }
    
    override suspend fun analyzePosition(fen: String, depth: Int): EngineAnalysis = withContext(Dispatchers.IO) {
        if (!isInitialized.get()) {
            throw IllegalStateException("Engine not initialized")
        }
        
        sendCommand("position fen $fen")
        sendCommand("go depth $depth")
        
        var bestMove: String? = null
        var evaluation = 0.0
        var currentDepth = 0
        val pv = mutableListOf<String>()
        
        while (true) {
            val line = reader?.readLine() ?: break
            
            when {
                line.startsWith("info") && "score" in line -> {
                    val scoreMatch = Regex("score (cp|mate) (-?\\d+)").find(line)
                    scoreMatch?.let {
                        val type = it.groupValues[1]
                        val value = it.groupValues[2].toInt()
                        
                        evaluation = when (type) {
                            "cp" -> value / 100.0
                            "mate" -> if (value > 0) 100.0 else -100.0
                            else -> 0.0
                        }
                    }
                    
                    val depthMatch = Regex("depth (\\d+)").find(line)
                    depthMatch?.let {
                        currentDepth = it.groupValues[1].toInt()
                    }
                    
                    val pvMatch = Regex("pv (.+)").find(line)
                    pvMatch?.let {
                        pv.clear()
                        pv.addAll(it.groupValues[1].split(" "))
                    }
                }
                line.startsWith("bestmove") -> {
                    bestMove = line.split(" ").getOrNull(1)
                    break
                }
            }
        }
        
        EngineAnalysis(bestMove, evaluation, currentDepth, pv)
    }
    
    override suspend fun getBestMove(fen: String, depth: Int): String? {
        return analyzePosition(fen, depth).bestMove
    }
    
    override suspend fun shutdown() = withContext(Dispatchers.IO) {
        try {
            sendCommand("quit")
            process?.waitFor()
            reader?.close()
            writer?.close()
            process?.destroy()
            isInitialized.set(false)
            scope.cancel()
            Log.d(TAG, "Stockfish shutdown complete")
        } catch (e: Exception) {
            Log.e(TAG, "Error during shutdown", e)
        }
    }
    
    private fun sendCommand(command: String) {
        writer?.apply {
            write(command)
            newLine()
            flush()
        }
    }
    
    private suspend fun waitForResponse(expected: String) = withContext(Dispatchers.IO) {
        while (true) {
            val line = reader?.readLine() ?: break
            if (line.contains(expected)) break
        }
    }
}
