package com.antiquechessmaster.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antiquechessmaster.domain.model.Player
import com.antiquechessmaster.domain.repository.PlayerRepository
import com.antiquechessmaster.domain.usecase.SyncGamesUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HomeViewModel(
    private val playerRepository: PlayerRepository,
    private val syncGamesUseCase: SyncGamesUseCase
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()
    
    val currentPlayer: StateFlow<Player?> = playerRepository.getCurrentPlayer()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    
    fun onUsernameSubmit(username: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            val result = syncGamesUseCase(username.trim())
            
            result.fold(
                onSuccess = { newGamesCount ->
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            syncSuccess = true,
                            newGamesCount = newGamesCount
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            error = error.message ?: "Failed to sync games"
                        )
                    }
                }
            )
        }
    }
    
    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }
    
    fun dismissSuccess() {
        _uiState.update { it.copy(syncSuccess = false) }
    }
}

data class HomeUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val syncSuccess: Boolean = false,
    val newGamesCount: Int = 0
)
// app/src/main/java/com/antiquechessmaster/presentation/viewmodel/AnalysisViewModel.kt
package com.antiquechessmaster.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antiquechessmaster.domain.model.Game
import com.antiquechessmaster.domain.repository.GameRepository
import com.antiquechessmaster.domain.usecase.AnalyzeGameUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AnalysisViewModel(
    private val gameRepository: GameRepository,
    private val analyzeGameUseCase: AnalyzeGameUseCase
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(AnalysisUiState())
    val uiState: StateFlow<AnalysisUiState> = _uiState.asStateFlow()
    
    private val _analysisProgress = MutableStateFlow<AnalysisProgress>(AnalysisProgress.Idle)
    val analysisProgress: StateFlow<AnalysisProgress> = _analysisProgress.asStateFlow()
    
    fun loadGames(username: String) {
        viewModelScope.launch {
            gameRepository.getGames(username)
                .collect { games ->
                    _uiState.update { 
                        it.copy(
                            games = games,
                            unanalyzedCount = games.count { !it.analyzed }
                        )
                    }
                }
        }
    }
    
    fun startAnalysis(username: String) {
        viewModelScope.launch {
            _analysisProgress.value = AnalysisProgress.Running(0, 0)
            
            val unanalyzedGames = gameRepository.getUnanalyzedGames(username, 10)
            val total = unanalyzedGames.size
            
            if (total == 0) {
                _analysisProgress.value = AnalysisProgress.Completed(0)
                return@launch
            }
            
            unanalyzedGames.forEachIndexed { index, game ->
                _analysisProgress.value = AnalysisProgress.Running(index + 1, total)
                
                analyzeGameUseCase(game, username).fold(
                    onSuccess = {
                        // Continue to next game
                    },
                    onFailure = { error ->
                        _analysisProgress.value = AnalysisProgress.Error(error.message ?: "Analysis failed")
                        return@launch
                    }
                )
            }
            
            _analysisProgress.value = AnalysisProgress.Completed(total)
        }
    }
    
    fun stopAnalysis() {
        // Implementation for stopping analysis
        _analysisProgress.value = AnalysisProgress.Idle
    }
}

data class AnalysisUiState(
    val games: List<Game> = emptyList(),
    val unanalyzedCount: Int = 0
)

sealed class AnalysisProgress {
    object Idle : AnalysisProgress()
    data class Running(val current: Int, val total: Int) : AnalysisProgress()
    data class Completed(val analyzedCount: Int) : AnalysisProgress()
    data class Error(val message: String) : AnalysisProgress()
}
// app/src/main/java/com/antiquechessmaster/presentation/viewmodel/InsightsViewModel.kt
package com.antiquechessmaster.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antiquechessmaster.domain.model.Insight
import com.antiquechessmaster.domain.model.PlayerStats
import com.antiquechessmaster.domain.usecase.GetInsightsUseCase
import com.antiquechessmaster.domain.usecase.GetPlayerStatsUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class InsightsViewModel(
    private val getPlayerStatsUseCase: GetPlayerStatsUseCase,
    private val getInsightsUseCase: GetInsightsUseCase
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(InsightsUiState())
    val uiState: StateFlow<InsightsUiState> = _uiState.asStateFlow()
    
    fun loadInsights(username: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            
            try {
                val stats = getPlayerStatsUseCase(username)
                val insights = getInsightsUseCase()
                
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        stats = stats,
                        insights = insights
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }
}

data class InsightsUiState(
    val isLoading: Boolean = false,
    val stats: PlayerStats? = null,
    val insights: List<Insight> = emptyList(),
    val error: String? = null
)
// app/src/main/java/com/antiquechessmaster/presentation/viewmodel/SettingsViewModel.kt
package com.antiquechessmaster.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antiquechessmaster.domain.repository.PlayerRepository
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val playerRepository: PlayerRepository
) : ViewModel() {
    
    fun clearData() {
        viewModelScope.launch {
            playerRepository.clearPlayer()
        }
    }
}
