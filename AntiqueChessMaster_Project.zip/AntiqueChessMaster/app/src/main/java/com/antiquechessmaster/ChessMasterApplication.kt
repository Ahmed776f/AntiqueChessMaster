package com.antiquechessmaster

import android.app.Application
import com.antiquechessmaster.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class ChessMasterApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@ChessMasterApplication)
            modules(appModule)
        }
    }
}
