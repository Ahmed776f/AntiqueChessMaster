package com.antiquechessmaster.domain.model

import java.util.Date

data class Player(
    val username: String,
    val lastSync: Date?,
    val rating: Int?,
    val avatarUrl: String?
)
// app/src/main/java/com/antiquechessmaster/domain/model/Game.kt
package com.antiquechessmaster.domain.model

import java.util.Date

data class Game(
    val gameId: String,
    val username: String,
    val pgn: String,
    val date: Date,
    val analyzed: Boolean,
    val whitePlayer: String?,
    val blackPlayer: String?,
    val result: String?,
    val timeControl: String?
)
// app/src/main/java/com/antiquechessmaster/domain/model/MoveAnalysis.kt
package com.antiquechessmaster.domain.model

data class MoveAnalysis(
    val gameId: String,
    val moveNumber: Int,
    val fen: String,
    val playedMove: String,
    val bestMove: String?,
    val evaluation: Double?,
    val previousEvaluation: Double?,
    val evaluationDelta: Double,
    val mistakeType: MistakeType,
    val isPlayerMove: Boolean
)

enum class MistakeType {
    GOOD,
    INACCURACY,
    MISTAKE,
    BLUNDER;

    companion object {
        fun fromDelta(delta: Double): MistakeType {
            return when {
                delta < 0.5 -> GOOD
                delta < 1.5 -> INACCURACY
                delta < 3.0 -> MISTAKE
                else -> BLUNDER
            }
        }
    }
}
// app/src/main/java/com/antiquechessmaster/domain/model/PlayerStats.kt
package com.antiquechessmaster.domain.model

data class PlayerStats(
    val totalGames: Int,
    val analyzedGames: Int,
    val blunders: Int,
    val mistakes: Int,
    val inaccuracies: Int,
    val accuracy: Double
)
// app/src/main/java/com/antiquechessmaster/domain/model/Insight.kt
package com.antiquechessmaster.domain.model

data class Insight(
    val category: String,
    val description: String,
    val severity: InsightSeverity,
    val recommendation: String,
    val occurrenceCount: Int
)

enum class InsightSeverity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
