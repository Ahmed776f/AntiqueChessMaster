package com.antiquechessmaster.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.antiquechessmaster.MainActivity
import com.antiquechessmaster.R
import com.antiquechessmaster.domain.usecase.AnalyzeGameUseCase
import kotlinx.coroutines.*
import org.koin.android.ext.android.inject

class AnalysisService : Service() {
    
    private val analyzeGameUseCase: AnalyzeGameUseCase by inject()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val binder = LocalBinder()
    
    companion object {
        const val CHANNEL_ID = "analysis_channel"
        const val NOTIFICATION_ID = 1
    }
    
    inner class LocalBinder : Binder() {
        fun getService(): AnalysisService = this@AnalysisService
    }
    
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }
    
    override fun onBind(intent: Intent?): IBinder = binder
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val username = intent?.getStringExtra("username") ?: return START_NOT_STICKY
        
        startForeground(NOTIFICATION_ID, createNotification("Starting analysis..."))
        
        serviceScope.launch {
            // Background analysis logic
            // This would connect to repositories and analyze games sequentially
        }
        
        return START_NOT_STICKY
    }
    
    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Game Analysis",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress of chess game analysis"
            }
            
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(content: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Analyzing Chess Games")
        .setContentText(content)
        .setSmallIcon(R.drawable.ic_notification)
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()
}
