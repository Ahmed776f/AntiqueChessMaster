package com.antiquechessmaster.data.repository

import com.antiquechessmaster.data.local.dao.PlayerDao
import com.antiquechessmaster.data.local.entity.PlayerEntity
import com.antiquechessmaster.domain.model.Player
import com.antiquechessmaster.domain.repository.PlayerRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Date

class PlayerRepositoryImpl(private val playerDao: PlayerDao) : PlayerRepository {
    
    override suspend fun getPlayer(username: String): Player? {
        return playerDao.getPlayer(username)?.toDomain()
    }
    
    override fun getCurrentPlayer(): Flow<Player?> {
        return playerDao.getCurrentPlayer().map { it?.toDomain() }
    }
    
    override suspend fun savePlayer(player: Player) {
        playerDao.insertPlayer(player.toEntity())
    }
    
    override suspend fun updateLastSync(username: String) {
        val player = playerDao.getPlayer(username)
        player?.let {
            playerDao.updatePlayer(it.copy(lastSync = Date()))
        }
    }
    
    override suspend fun clearPlayer() {
        playerDao.clearAll()
    }
    
    private fun PlayerEntity.toDomain() = Player(
        username = username,
        lastSync = lastSync,
        rating = rating,
        avatarUrl = avatarUrl
    )
    
    private fun Player.toEntity() = PlayerEntity(
        username = username,
        lastSync = lastSync,
        rating = rating,
        avatarUrl = avatarUrl
    )
}
// app/src/main/java/com/antiquechessmaster/data/repository/GameRepositoryImpl.kt
package com.antiquechessmaster.data.repository

import com.antiquechessmaster.data.local.dao.GameDao
import com.antiquechessmaster.data.local.entity.GameEntity
import com.antiquechessmaster.domain.model.Game
import com.antiquechessmaster.domain.repository.GameRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Date

class GameRepositoryImpl(
    private val gameDao: GameDao,
    private val playerDao: com.antiquechessmaster.data.local.dao.PlayerDao,
    private val moveAnalysisDao: com.antiquechessmaster.data.local.dao.MoveAnalysisDao
) : GameRepository {
    
    override fun getGames(username: String): Flow<List<Game>> {
        return gameDao.getGamesByUsername(username).map { entities ->
            entities.map { it.toDomain() }
        }
    }
    
    override suspend fun getUnanalyzedGames(username: String, limit: Int): List<Game> {
        return gameDao.getUnanalyzedGames(username, limit).map { it.toDomain() }
    }
    
    override suspend fun saveGames(games: List<Game>) {
        gameDao.insertGames(games.map { it.toEntity() })
    }
    
    override suspend fun markAsAnalyzed(gameId: String) {
        gameDao.markAsAnalyzed(gameId)
    }
    
    override suspend fun gameExists(gameId: String): Boolean {
        return gameDao.gameExists(gameId)
    }
    
    override suspend fun getStats(username: String): Pair<Int, Int> {
        val total = gameDao.getGameCount(username)
        val analyzed = gameDao.getAnalyzedCount(username)
        return Pair(total, analyzed)
    }
    
    private fun GameEntity.toDomain() = Game(
        gameId = gameId,
        username = username,
        pgn = pgn,
        date = date,
        analyzed = analyzed,
        whitePlayer = whitePlayer,
        blackPlayer = blackPlayer,
        result = result,
        timeControl = timeControl
    )
    
    private fun Game.toEntity() = GameEntity(
        gameId = gameId,
        username = username,
        pgn = pgn,
        date = date,
        analyzed = analyzed,
        whitePlayer = whitePlayer,
        blackPlayer = blackPlayer,
        result = result,
        timeControl = timeControl
    )
}
// app/src/main/java/com/antiquechessmaster/data/repository/ChessRepositoryImpl.kt
package com.antiquechessmaster.data.repository

import com.antiquechessmaster.data.remote.ChessComApiClient
import com.antiquechessmaster.data.remote.dto.PlayerProfileDto
import com.antiquechessmaster.domain.model.Game
import com.antiquechessmaster.domain.repository.ChessRepository
import java.util.Date

class ChessRepositoryImpl(private val apiClient: ChessComApiClient) : ChessRepository {
    
    override suspend fun fetchPlayerProfile(username: String): Result<PlayerProfileDto> {
        return apiClient.getPlayerProfile(username)
    }
    
    override suspend fun fetchRecentGames(username: String, limit: Int): Result<List<Game>> {
        val archivesResult = apiClient.getGameArchives(username)
        
        if (archivesResult.isFailure) {
            return Result.failure(archivesResult.exceptionOrNull() ?: Exception("Unknown error"))
        }
        
        val archives = archivesResult.getOrNull()?.archives ?: emptyList()
        val games = mutableListOf<Game>()
        
        // Get games from most recent archives
        for (archiveUrl in archives.takeLast(3).reversed()) {
            if (games.size >= limit) break
            
            val gamesResult = apiClient.getGamesFromArchive(archiveUrl)
            gamesResult.getOrNull()?.games?.let { gameDtos ->
                games.addAll(gameDtos.map { dto ->
                    Game(
                        gameId = dto.url.substringAfterLast("/"),
                        username = username,
                        pgn = dto.pgn ?: "",
                        date = Date(dto.endTime * 1000),
                        analyzed = false,
                        whitePlayer = dto.white.username,
                        blackPlayer = dto.black.username,
                        result = when (username.lowercase()) {
                            dto.white.username.lowercase() -> dto.white.result
                            dto.black.username.lowercase() -> dto.black.result
                            else -> ""
                        },
                        timeControl = dto.timeClass
                    )
                })
            }
        }
        
        return Result.success(games.take(limit))
    }
}
// app/src/main/java/com/antiquechessmaster/data/repository/MoveAnalysisRepositoryImpl.kt
package com.antiquechessmaster.data.repository

import com.antiquechessmaster.data.local.dao.MoveAnalysisDao
import com.antiquechessmaster.data.local.entity.MoveAnalysisEntity
import com.antiquechessmaster.domain.model.MistakeType
import com.antiquechessmaster.domain.model.MoveAnalysis
import com.antiquechessmaster.domain.repository.MoveAnalysisRepository

class MoveAnalysisRepositoryImpl(private val moveAnalysisDao: MoveAnalysisDao) : MoveAnalysisRepository {
    
    override suspend fun saveAnalyses(analyses: List<MoveAnalysis>) {
        moveAnalysisDao.insertAnalyses(analyses.map { it.toEntity() })
    }
    
    override suspend fun getWorstMoves(limit: Int): List<MoveAnalysis> {
        return moveAnalysisDao.getWorstMoves(limit).map { it.toDomain() }
    }
    
    override suspend fun getMistakeDistribution(): Map<MistakeType, Int> {
        val counts = moveAnalysisDao.getMistakeDistribution()
        return counts.associate { 
            MistakeType.valueOf(it.mistakeType) to it.count 
        }
    }
    
    private fun MoveAnalysisEntity.toDomain() = MoveAnalysis(
        gameId = gameId,
        moveNumber = moveNumber,
        fen = fen,
        playedMove = playedMove,
        bestMove = bestMove,
        evaluation = evaluation,
        previousEvaluation = previousEvaluation,
        evaluationDelta = evaluationDelta,
        mistakeType = MistakeType.valueOf(mistakeType),
        isPlayerMove = isPlayerMove
    )
    
    private fun MoveAnalysis.toEntity() = MoveAnalysisEntity(
        gameId = gameId,
        moveNumber = moveNumber,
        fen = fen,
        playedMove = playedMove,
        bestMove = bestMove,
        evaluation = evaluation,
        previousEvaluation = previousEvaluation,
        evaluationDelta = evaluationDelta,
        mistakeType = mistakeType.name,
        isPlayerMove = isPlayerMove
    )
}
