package com.antiquechessmaster.domain.usecase

import com.antiquechessmaster.domain.model.Game
import com.antiquechessmaster.domain.repository.ChessRepository
import com.antiquechessmaster.domain.repository.GameRepository
import com.antiquechessmaster.domain.repository.PlayerRepository
import java.util.Date

class SyncGamesUseCase(
    private val chessRepository: ChessRepository,
    private val gameRepository: GameRepository,
    private val playerRepository: PlayerRepository
) {
    suspend operator fun invoke(username: String): Result<Int> {
        return try {
            // Fetch player profile
            val profileResult = chessRepository.fetchPlayerProfile(username)
            if (profileResult.isFailure) {
                return Result.failure(profileResult.exceptionOrNull() ?: Exception("Unknown error"))
            }
            
            // Fetch recent games
            val gamesResult = chessRepository.fetchRecentGames(username, 30)
            if (gamesResult.isFailure) {
                return Result.failure(gamesResult.exceptionOrNull() ?: Exception("Failed to fetch games"))
            }
            
            val games = gamesResult.getOrNull() ?: emptyList()
            
            // Filter out existing games
            val newGames = games.filter { !gameRepository.gameExists(it.gameId) }
            
            // Save new games
            if (newGames.isNotEmpty()) {
                gameRepository.saveGames(newGames)
            }
            
            // Update player sync time
            playerRepository.updateLastSync(username)
            
            Result.success(newGames.size)
            
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
// app/src/main/java/com/antiquechessmaster/domain/usecase/AnalyzeGameUseCase.kt
package com.antiquechessmaster.domain.usecase

import android.util.Log
import com.antiquechessmaster.domain.engine.ChessEngine
import com.antiquechessmaster.domain.model.*
import com.antiquechessmaster.domain.repository.GameRepository
import com.antiquechessmaster.domain.repository.MoveAnalysisRepository
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.move.MoveList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AnalyzeGameUseCase(
    private val engine: ChessEngine,
    private val gameRepository: GameRepository,
    private val moveAnalysisRepository: MoveAnalysisRepository,
    private val classifyMistakeUseCase: ClassifyMistakeUseCase
) {
    companion object {
        private const val TAG = "AnalyzeGame"
        private const val ANALYSIS_DEPTH = 12
    }
    
    suspend operator fun invoke(game: Game, username: String): Result<Unit> = withContext(Dispatchers.Default) {
        try {
            Log.d(TAG, "Starting analysis for game ${game.gameId}")
            
            val board = Board()
            val moveList = MoveList()
            moveList.loadFromSan(game.pgn)
            
            val analyses = mutableListOf<MoveAnalysis>()
            var moveNumber = 0
            var previousEval = 0.0
            
            // Determine player's side
            val playerSide = when {
                game.pgn.contains("[White \"$username\"") -> Side.WHITE
                game.pgn.contains("[Black \"$username\"") -> Side.BLACK
                else -> Side.WHITE
            }
            
            for (move in moveList) {
                moveNumber++
                val fenBefore = board.fen
                
                // Analyze position before move
                val analysis = engine.analyzePosition(fenBefore, ANALYSIS_DEPTH)
                val bestMove = analysis.bestMove
                
                // Make the move
                board.doMove(move)
                
                // Analyze position after move
                val postAnalysis = engine.analyzePosition(board.fen, ANALYSIS_DEPTH)
                val currentEval = postAnalysis.evaluation
                
                // Calculate delta (always positive for mistake magnitude)
                val evalDelta = kotlin.math.abs(currentEval - previousEval)
                
                // Classify mistake
                val mistakeType = classifyMistakeUseCase(evalDelta)
                
                // Check if it's player's move
                val isPlayerMove = when (playerSide) {
                    Side.WHITE -> moveNumber % 2 == 1
                    Side.BLACK -> moveNumber % 2 == 0
                }
                
                analyses.add(MoveAnalysis(
                    gameId = game.gameId,
                    moveNumber = moveNumber,
                    fen = fenBefore,
                    playedMove = move.toString(),
                    bestMove = bestMove,
                    evaluation = currentEval,
                    previousEvaluation = previousEval,
                    evaluationDelta = evalDelta,
                    mistakeType = mistakeType,
                    isPlayerMove = isPlayerMove
                ))
                
                previousEval = currentEval
            }
            
            // Save analyses
            moveAnalysisRepository.saveAnalyses(analyses)
            gameRepository.markAsAnalyzed(game.gameId)
            
            Log.d(TAG, "Analysis complete for game ${game.gameId}")
            Result.success(Unit)
            
        } catch (e: Exception) {
            Log.e(TAG, "Analysis failed for game ${game.gameId}", e)
            Result.failure(e)
        }
    }
}

// Repository interface needed
interface MoveAnalysisRepository {
    suspend fun saveAnalyses(analyses: List<MoveAnalysis>)
    suspend fun getWorstMoves(limit: Int): List<MoveAnalysis>
    suspend fun getMistakeDistribution(): Map<MistakeType, Int>
}
// app/src/main/java/com/antiquechessmaster/domain/usecase/ClassifyMistakeUseCase.kt
package com.antiquechessmaster.domain.usecase

import com.antiquechessmaster.domain.model.MistakeType

class ClassifyMistakeUseCase {
    operator fun invoke(evaluationDelta: Double): MistakeType {
        return MistakeType.fromDelta(evaluationDelta)
    }
}
// app/src/main/java/com/antiquechessmaster/domain/usecase/GetPlayerStatsUseCase.kt
package com.antiquechessmaster.domain.usecase

import com.antiquechessmaster.domain.model.PlayerStats
import com.antiquechessmaster.domain.repository.GameRepository
import com.antiquechessmaster.domain.repository.MoveAnalysisRepository

class GetPlayerStatsUseCase(
    private val gameRepository: GameRepository,
    private val moveAnalysisRepository: MoveAnalysisRepository
) {
    suspend operator fun invoke(username: String): PlayerStats {
        val (totalGames, analyzedGames) = gameRepository.getStats(username)
        val distribution = moveAnalysisRepository.getMistakeDistribution()
        
        val blunders = distribution[MistakeType.BLUNDER] ?: 0
        val mistakes = distribution[MistakeType.MISTAKE] ?: 0
        val inaccuracies = distribution[MistakeType.INACCURACY] ?: 0
        val goodMoves = distribution[MistakeType.GOOD] ?: 0
        
        val totalAnalyzed = blunders + mistakes + inaccuracies + goodMoves
        val accuracy = if (totalAnalyzed > 0) {
            (goodMoves.toDouble() / totalAnalyzed) * 100
        } else 0.0
        
        return PlayerStats(
            totalGames = totalGames,
            analyzedGames = analyzedGames,
            blunders = blunders,
            mistakes = mistakes,
            inaccuracies = inaccuracies,
            accuracy = accuracy
        )
    }
}
// app/src/main/java/com/antiquechessmaster/domain/usecase/GetInsightsUseCase.kt
package com.antiquechessmaster.domain.usecase

import com.antiquechessmaster.domain.model.Insight
import com.antiquechessmaster.domain.model.InsightSeverity
import com.antiquechessmaster.domain.model.MistakeType
import com.antiquechessmaster.domain.repository.MoveAnalysisRepository

class GetInsightsUseCase(
    private val moveAnalysisRepository: MoveAnalysisRepository
) {
    suspend operator fun invoke(): List<Insight> {
        val worstMoves = moveAnalysisRepository.getWorstMoves(50)
        val distribution = moveAnalysisRepository.getMistakeDistribution()
        
        val insights = mutableListOf<Insight>()
        
        // Calculate blunder rate
        val totalMistakes = distribution.values.sum()
        val blunderCount = distribution[MistakeType.BLUNDER] ?: 0
        val blunderRate = if (totalMistakes > 0) blunderCount.toDouble() / totalMistakes else 0.0
        
        if (blunderRate > 0.15) {
            insights.add(Insight(
                category = "Blunder Frequency",
                description = "You blunder in ${(blunderRate * 100).toInt()}% of analyzed moves",
                severity = if (blunderRate > 0.25) InsightSeverity.CRITICAL else InsightSeverity.HIGH,
                recommendation = "Practice tactical puzzles daily. Spend more time on each move.",
                occurrenceCount = blunderCount
            ))
        }
        
        // Time management insight
        val timeTroubleBlunders = worstMoves.count { 
            it.evaluationDelta > 2.0 && it.moveNumber > 30 
        }
        if (timeTroubleBlunders > 5) {
            insights.add(Insight(
                category = "Time Management",
                description = "Many blunders occur in later stages of the game",
                severity = InsightSeverity.MEDIUM,
                recommendation = "Improve endgame technique and time management",
                occurrenceCount = timeTroubleBlunders
            ))
        }
        
        // Opening insight
        val openingMistakes = worstMoves.count { it.moveNumber <= 10 }
        if (openingMistakes > 3) {
            insights.add(Insight(
                category = "Opening Knowledge",
                description = "Several mistakes in the opening phase",
                severity = InsightSeverity.HIGH,
                recommendation = "Study your opening lines more deeply",
                occurrenceCount = openingMistakes
            ))
        }
        
        // Tactical awareness
        val tacticalBlunders = worstMoves.count { it.evaluationDelta > 3.0 }
        if (tacticalBlunders > 10) {
            insights.add(Insight(
                category = "Tactical Awareness",
                description = "Significant evaluation drops suggest tactical oversights",
                severity = InsightSeverity.CRITICAL,
                recommendation = "Focus on calculation training and board visualization",
                occurrenceCount = tacticalBlunders
            ))
        }
        
        return insights.sortedByDescending { it.severity.ordinal }
    }
}
