package com.antiquechessmaster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.antiquechessmaster.presentation.screen.*
import com.antiquechessmaster.presentation.theme.AntiqueChessMasterTheme
import org.koin.androidx.compose.koinViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AntiqueChessMasterTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ChessMasterApp()
                }
            }
        }
    }
}

@Composable
fun ChessMasterApp() {
    val navController = rememberNavController()
    
    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                onNavigateToAnalysis = { navController.navigate("analysis") },
                onNavigateToInsights = { navController.navigate("insights") }
            )
        }
        
        composable("analysis") {
            val homeViewModel: com.antiquechessmaster.presentation.viewmodel.HomeViewModel = koinViewModel()
            val currentPlayer by homeViewModel.currentPlayer.collectAsState()
            
            currentPlayer?.let { player ->
                AnalysisScreen(
                    username = player.username,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
        
        composable("insights") {
            val homeViewModel: com.antiquechessmaster.presentation.viewmodel.HomeViewModel = koinViewModel()
            val currentPlayer by homeViewModel.currentPlayer.collectAsState()
            
            currentPlayer?.let { player ->
                InsightsScreen(
                    username = player.username,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
