package com.antiquechessmaster.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.antiquechessmaster.data.local.converter.DateConverter
import com.antiquechessmaster.data.local.dao.*
import com.antiquechessmaster.data.local.entity.*

@Database(
    entities = [
        PlayerEntity::class,
        GameEntity::class,
        MoveAnalysisEntity::class,
        WeaknessStatsEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(DateConverter::class)
abstract class ChessDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao
    abstract fun gameDao(): GameDao
    abstract fun moveAnalysisDao(): MoveAnalysisDao
    abstract fun weaknessStatsDao(): WeaknessStatsDao
}
// app/src/main/java/com/antiquechessmaster/data/local/converter/DateConverter.kt
package com.antiquechessmaster.data.local.converter

import androidx.room.TypeConverter
import java.util.Date

class DateConverter {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}
// app/src/main/java/com/antiquechessmaster/data/local/entity/PlayerEntity.kt
package com.antiquechessmaster.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "players")
data class PlayerEntity(
    @PrimaryKey
    val username: String,
    val lastSync: Date? = null,
    val rating: Int? = null,
    val avatarUrl: String? = null
)
// app/src/main/java/com/antiquechessmaster/data/local/entity/GameEntity.kt
package com.antiquechessmaster.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.Date

@Entity(
    tableName = "games",
    indices = [Index(value = ["gameId"], unique = true)]
)
data class GameEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val gameId: String,
    val username: String,
    val pgn: String,
    val date: Date,
    val analyzed: Boolean = false,
    val whitePlayer: String? = null,
    val blackPlayer: String? = null,
    val result: String? = null,
    val timeControl: String? = null
)
// app/src/main/java/com/antiquechessmaster/data/local/entity/MoveAnalysisEntity.kt
package com.antiquechessmaster.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "move_analysis",
    primaryKeys = ["gameId", "moveNumber"],
    foreignKeys = [
        ForeignKey(
            entity = GameEntity::class,
            parentColumns = ["gameId"],
            childColumns = ["gameId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("gameId")]
)
data class MoveAnalysisEntity(
    val gameId: String,
    val moveNumber: Int,
    val fen: String,
    val playedMove: String,
    val bestMove: String?,
    val evaluation: Double?,
    val previousEvaluation: Double?,
    val evaluationDelta: Double,
    val mistakeType: String, // GOOD, INACCURACY, MISTAKE, BLUNDER
    val isPlayerMove: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
// app/src/main/java/com/antiquechessmaster/data/local/entity/WeaknessStatsEntity.kt
package com.antiquechessmaster.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weakness_stats")
data class WeaknessStatsEntity(
    @PrimaryKey
    val category: String,
    val count: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis()
)
// app/src/main/java/com/antiquechessmaster/data/local/dao/PlayerDao.kt
package com.antiquechessmaster.data.local.dao

import androidx.room.*
import com.antiquechessmaster.data.local.entity.PlayerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerDao {
    @Query("SELECT * FROM players WHERE username = :username")
    suspend fun getPlayer(username: String): PlayerEntity?

    @Query("SELECT * FROM players LIMIT 1")
    fun getCurrentPlayer(): Flow<PlayerEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity)

    @Update
    suspend fun updatePlayer(player: PlayerEntity)

    @Delete
    suspend fun deletePlayer(player: PlayerEntity)

    @Query("DELETE FROM players")
    suspend fun clearAll()
}
// app/src/main/java/com/antiquechessmaster/data/local/dao/GameDao.kt
package com.antiquechessmaster.data.local.dao

import androidx.room.*
import com.antiquechessmaster.data.local.entity.GameEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM games WHERE username = :username ORDER BY date DESC")
    fun getGamesByUsername(username: String): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE username = :username AND analyzed = 0 ORDER BY date DESC LIMIT :limit")
    suspend fun getUnanalyzedGames(username: String, limit: Int = 10): List<GameEntity>

    @Query("SELECT * FROM games WHERE gameId = :gameId")
    suspend fun getGameById(gameId: String): GameEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM games WHERE gameId = :gameId)")
    suspend fun gameExists(gameId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGame(game: GameEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGames(games: List<GameEntity>)

    @Update
    suspend fun updateGame(game: GameEntity)

    @Query("UPDATE games SET analyzed = 1 WHERE gameId = :gameId")
    suspend fun markAsAnalyzed(gameId: String)

    @Query("SELECT COUNT(*) FROM games WHERE username = :username")
    suspend fun getGameCount(username: String): Int

    @Query("SELECT COUNT(*) FROM games WHERE username = :username AND analyzed = 1")
    suspend fun getAnalyzedCount(username: String): Int

    @Query("DELETE FROM games WHERE username = :username")
    suspend fun deleteGamesByUsername(username: String)
}
// app/src/main/java/com/antiquechessmaster/data/local/dao/MoveAnalysisDao.kt
package com.antiquechessmaster.data.local.dao

import androidx.room.*
import com.antiquechessmaster.data.local.entity.MoveAnalysisEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MoveAnalysisDao {
    @Query("SELECT * FROM move_analysis WHERE gameId = :gameId ORDER BY moveNumber")
    suspend fun getAnalysisForGame(gameId: String): List<MoveAnalysisEntity>

    @Query("""
        SELECT * FROM move_analysis 
        WHERE isPlayerMove = 1 
        AND mistakeType IN ('INACCURACY', 'MISTAKE', 'BLUNDER')
        ORDER BY evaluationDelta DESC
        LIMIT :limit
    """)
    suspend fun getWorstMoves(limit: Int = 20): List<MoveAnalysisEntity>

    @Query("""
        SELECT mistakeType, COUNT(*) as count 
        FROM move_analysis 
        WHERE isPlayerMove = 1 
        GROUP BY mistakeType
    """)
    suspend fun getMistakeDistribution(): List<MistakeCount>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalysis(analysis: MoveAnalysisEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalyses(analyses: List<MoveAnalysisEntity>)

    @Query("DELETE FROM move_analysis WHERE gameId = :gameId")
    suspend fun deleteAnalysisForGame(gameId: String)

    data class MistakeCount(
        val mistakeType: String,
        val count: Int
    )
}
// app/src/main/java/com/antiquechessmaster/data/local/dao/WeaknessStatsDao.kt
package com.antiquechessmaster.data.local.dao

import androidx.room.*
import com.antiquechessmaster.data.local.entity.WeaknessStatsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WeaknessStatsDao {
    @Query("SELECT * FROM weakness_stats ORDER BY count DESC")
    fun getAllStats(): Flow<List<WeaknessStatsEntity>>

    @Query("SELECT * FROM weakness_stats WHERE category = :category")
    suspend fun getStat(category: String): WeaknessStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStat(stat: WeaknessStatsEntity)

    @Query("UPDATE weakness_stats SET count = count + 1 WHERE category = :category")
    suspend fun incrementCount(category: String)

    @Query("DELETE FROM weakness_stats")
    suspend fun clearAll()
}
