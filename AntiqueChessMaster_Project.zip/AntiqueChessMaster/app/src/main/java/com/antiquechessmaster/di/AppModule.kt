package com.antiquechessmaster.di

import android.content.Context
import androidx.room.Room
import com.antiquechessmaster.data.local.ChessDatabase
import com.antiquechessmaster.data.remote.ChessComApiClient
import com.antiquechessmaster.data.repository.ChessRepositoryImpl
import com.antiquechessmaster.data.repository.GameRepositoryImpl
import com.antiquechessmaster.data.repository.PlayerRepositoryImpl
import com.antiquechessmaster.domain.engine.StockfishEngine
import com.antiquechessmaster.domain.repository.ChessRepository
import com.antiquechessmaster.domain.repository.GameRepository
import com.antiquechessmaster.domain.repository.PlayerRepository
import com.antiquechessmaster.domain.usecase.*
import com.antiquechessmaster.presentation.viewmodel.*
import io.ktor.client.*
import io.ktor.client.engine.android.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.logging.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    // Ktor Client
    single {
        HttpClient(Android) {
            install(ContentNegotiation) {
                json(Json {
                    ignoreUnknownKeys = true
                    prettyPrint = true
                })
            }
            install(Logging) {
                level = LogLevel.BODY
            }
        }
    }

    // Database
    single {
        Room.databaseBuilder(
            androidContext(),
            ChessDatabase::class.java,
            "chess_database"
        ).build()
    }

    single { get<ChessDatabase>().playerDao() }
    single { get<ChessDatabase>().gameDao() }
    single { get<ChessDatabase>().moveAnalysisDao() }
    single { get<ChessDatabase>().weaknessStatsDao() }

    // API
    single { ChessComApiClient(get()) }

    // Engine
    single { StockfishEngine(androidContext()) }

    // Repositories
    single<PlayerRepository> { PlayerRepositoryImpl(get()) }
    single<GameRepository> { GameRepositoryImpl(get(), get(), get()) }
    single<ChessRepository> { ChessRepositoryImpl(get()) }

    // Use Cases
    factory { SyncGamesUseCase(get(), get(), get()) }
    factory { AnalyzeGameUseCase(get(), get(), get()) }
    factory { GetPlayerStatsUseCase(get(), get(), get()) }
    factory { GetInsightsUseCase(get(), get()) }
    factory { ClassifyMistakeUseCase() }

    // ViewModels
    viewModel { HomeViewModel(get(), get()) }
    viewModel { AnalysisViewModel(get(), get()) }
    viewModel { InsightsViewModel(get()) }
    viewModel { SettingsViewModel(get()) }
}
