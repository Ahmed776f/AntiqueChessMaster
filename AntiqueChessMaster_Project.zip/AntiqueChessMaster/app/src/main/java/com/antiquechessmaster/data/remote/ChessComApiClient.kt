package com.antiquechessmaster.data.remote

import android.util.Log
import com.antiquechessmaster.data.remote.dto.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.http.*
import kotlinx.serialization.json.Json
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class ChessComApiClient(private val client: HttpClient) {
    
    private val baseUrl = "https://api.chess.com/pub/player"
    
    suspend fun getPlayerProfile(username: String): Result<PlayerProfileDto> {
        return try {
            val encodedUsername = URLEncoder.encode(username.lowercase(), StandardCharsets.UTF_8.toString())
            val response = client.get("$baseUrl/$encodedUsername") {
                headers {
                    append("User-Agent", "AntiqueChessMaster/1.0")
                }
            }
            
            if (response.status.isSuccess()) {
                Result.success(response.body())
            } else {
                Result.failure(Exception("Player not found"))
            }
        } catch (e: Exception) {
            Log.e("ChessComApi", "Error fetching profile", e)
            Result.failure(e)
        }
    }
    
    suspend fun getGameArchives(username: String): Result<GameArchivesDto> {
        return try {
            val encodedUsername = URLEncoder.encode(username.lowercase(), StandardCharsets.UTF_8.toString())
            val response = client.get("$baseUrl/$encodedUsername/games/archives") {
                headers {
                    append("User-Agent", "AntiqueChessMaster/1.0")
                }
            }
            
            if (response.status.isSuccess()) {
                Result.success(response.body())
            } else {
                Result.failure(Exception("Failed to fetch archives"))
            }
        } catch (e: Exception) {
            Log.e("ChessComApi", "Error fetching archives", e)
            Result.failure(e)
        }
    }
    
    suspend fun getGamesFromArchive(archiveUrl: String): Result<GamesListDto> {
        return try {
            val response = client.get(archiveUrl) {
                headers {
                    append("User-Agent", "AntiqueChessMaster/1.0")
                }
            }
            
            if (response.status.isSuccess()) {
                Result.success(response.body())
            } else {
                Result.failure(Exception("Failed to fetch games"))
            }
        } catch (e: Exception) {
            Log.e("ChessComApi", "Error fetching games from archive", e)
            Result.failure(e)
        }
    }
    
    suspend fun downloadPgn(pgnUrl: String): Result<String> {
        return try {
            val response = client.get(pgnUrl) {
                headers {
                    append("User-Agent", "AntiqueChessMaster/1.0")
                }
            }
            
            if (response.status.isSuccess()) {
                Result.success(response.body())
            } else {
                Result.failure(Exception("Failed to download PGN"))
            }
        } catch (e: Exception) {
            Log.e("ChessComApi", "Error downloading PGN", e)
            Result.failure(e)
        }
    }
}
// app/src/main/java/com/antiquechessmaster/data/remote/dto/PlayerProfileDto.kt
package com.antiquechessmaster.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PlayerProfileDto(
    @SerialName("username")
    val username: String,
    @SerialName("player_id")
    val playerId: Long,
    @SerialName("title")
    val title: String? = null,
    @SerialName("status")
    val status: String,
    @SerialName("avatar")
    val avatar: String? = null,
    @SerialName("country")
    val country: String? = null,
    @SerialName("joined")
    val joined: Long,
    @SerialName("last_online")
    val lastOnline: Long,
    @SerialName("followers")
    val followers: Int,
    @SerialName("is_streamer")
    val isStreamer: Boolean,
    @SerialName("twitch_url")
    val twitchUrl: String? = null
)
// app/src/main/java/com/antiquechessmaster/data/remote/dto/GameArchivesDto.kt
package com.antiquechessmaster.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class GameArchivesDto(
    @SerialName("archives")
    val archives: List<String>
)
// app/src/main/java/com/antiquechessmaster/data/remote/dto/GamesListDto.kt
package com.antiquechessmaster.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class GamesListDto(
    @SerialName("games")
    val games: List<GameDto>
)

@Serializable
data class GameDto(
    @SerialName("url")
    val url: String,
    @SerialName("pgn")
    val pgn: String? = null,
    @SerialName("time_control")
    val timeControl: String,
    @SerialName("end_time")
    val endTime: Long,
    @SerialName("rated")
    val rated: Boolean,
    @SerialName("fen")
    val fen: String,
    @SerialName("time_class")
    val timeClass: String,
    @SerialName("rules")
    val rules: String,
    @SerialName("white")
    val white: PlayerInfoDto,
    @SerialName("black")
    val black: PlayerInfoDto
)

@Serializable
data class PlayerInfoDto(
    @SerialName("username")
    val username: String,
    @SerialName("rating")
    val rating: Int? = null,
    @SerialName("result")
    val result: String,
    @SerialName("@id")
    val id: String
)
