package com.antiquechessmaster.domain.repository

import com.antiquechessmaster.domain.model.Player
import kotlinx.coroutines.flow.Flow

interface PlayerRepository {
    suspend fun getPlayer(username: String): Player?
    fun getCurrentPlayer(): Flow<Player?>
    suspend fun savePlayer(player: Player)
    suspend fun updateLastSync(username: String)
    suspend fun clearPlayer()
}
// app/src/main/java/com/antiquechessmaster/domain/repository/GameRepository.kt
package com.antiquechessmaster.domain.repository

import com.antiquechessmaster.domain.model.Game
import kotlinx.coroutines.flow.Flow

interface GameRepository {
    fun getGames(username: String): Flow<List<Game>>
    suspend fun getUnanalyzedGames(username: String, limit: Int = 10): List<Game>
    suspend fun saveGames(games: List<Game>)
    suspend fun markAsAnalyzed(gameId: String)
    suspend fun gameExists(gameId: String): Boolean
    suspend fun getStats(username: String): Pair<Int, Int> // total, analyzed
}
// app/src/main/java/com/antiquechessmaster/domain/repository/ChessRepository.kt
package com.antiquechessmaster.domain.repository

import com.antiquechessmaster.data.remote.dto.PlayerProfileDto
import com.antiquechessmaster.domain.model.Game

interface ChessRepository {
    suspend fun fetchPlayerProfile(username: String): Result<PlayerProfileDto>
    suspend fun fetchRecentGames(username: String, limit: Int = 30): Result<List<Game>>
}
